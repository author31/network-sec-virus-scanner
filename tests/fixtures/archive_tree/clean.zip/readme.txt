this is a clean text file
no malware here
